# marketcap-widget
## Cryptocurrency Market Cap Desktop Widget for Mac OS (Übersicht).

Gets you the latest crypto market cap info right on your desktop!

# Setup
1. Install [Übersicht](http://tracesof.net/uebersicht/)
2. Download this repo and put the .widget file in you Übersicht widget folder. 

(How to install widgets [link](http://tracesof.net/uebersicht-widgets/#installation))

![Screenshot](https://github.com/zhanchengqian/marketcapwidget/blob/master/screenshot.png)

Data all coming from coinmarketcap.com

Modified from Sebastian Stiernborg's cryptowidget (BSD-2-Clause)
